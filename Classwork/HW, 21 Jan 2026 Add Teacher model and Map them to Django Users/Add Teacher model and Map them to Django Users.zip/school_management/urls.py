﻿from django.contrib import admin
from django.urls import path, include
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('teachers/', include('teachers.urls')),
    path('admin/', admin.site.urls),
]
